import 'package:flutter/material.dart';

class ListFormScreen extends StatefulWidget {
  const ListFormScreen({super.key});

  @override
  _ListFormScreenState createState() => _ListFormScreenState();
}

class _ListFormScreenState extends State<ListFormScreen> {
  final TextEditingController titleController = TextEditingController();
  final double Borders = 15;

  bool _isFormValid() {
    return titleController.text.isNotEmpty;
  }

  void _handleCreate() {
    if (_isFormValid()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("List created successfully!")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a title.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(240, 240, 240, 100),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                buildTextField(titleController, 'Title'),
                SizedBox(height: Borders),
                buildButton('CREATE', const Color.fromRGBO(217, 217, 217, 1), _isFormValid() ? _handleCreate : null),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(TextEditingController controller, String label) {
    return Container(
      decoration: BoxDecoration(
        color: const Color.fromRGBO(240, 240, 240, 100),
        borderRadius: BorderRadius.circular(Borders),
      ),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: TextField(
          controller: controller,
          decoration: InputDecoration(labelText: label),
          onChanged: (_) => setState(() {}),
        ),
      ),
    );
  }

  Widget buildButton(String text, Color color, VoidCallback? onPressed) {
    return SizedBox(
      width: double.infinity,
      height: 70,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Borders),
          ),
          backgroundColor: color,
        ),
        onPressed: onPressed,
        child: Text(text),
      ),
    );
  }
}
