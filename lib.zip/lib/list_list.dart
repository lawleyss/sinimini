import 'package:flutter/material.dart';

class Movie {
  final String title;
  final String director;
  final String duration;
  final List<String> genres;
  final double? rating;

  Movie({
    required this.title,
    required this.director,
    required this.duration,
    required this.genres,
    this.rating,
  });
}

class MovieListScreen extends StatefulWidget {
  const MovieListScreen({super.key});

  @override
  _MovieListScreenState createState() => _MovieListScreenState();
}

class _MovieListScreenState extends State<MovieListScreen> {
  final List<Movie> watchLater = [];
  final List<Movie> watched = [];

  void moveToWatched(Movie movie) {
    setState(() {
      watchLater.remove(movie);
      watched.add(movie);
    });
  }

  void moveToWatchLater(Movie movie) {
    setState(() {
      watched.remove(movie);
      watchLater.add(movie);
    });
  }

  Widget buildMovieCard(Movie movie, {required VoidCallback onMove}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(movie.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text("Director: ${movie.director}"),
            Text("Duration: ${movie.duration} min"),
            Text("Genres: ${movie.genres.join(", ")}"),
            if (movie.rating != null) Text("Rating: ${movie.rating!.toStringAsFixed(1)}/10"),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: onMove,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("Move", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Movie Lists")),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Watch Later", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: watchLater.length,
                itemBuilder: (context, index) {
                  return buildMovieCard(watchLater[index], onMove: () => moveToWatched(watchLater[index]));
                },
              ),
            ),
            const SizedBox(height: 15),
            const Text("Watched", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Expanded(
              child: ListView.builder(
                itemCount: watched.length,
                itemBuilder: (context, index) {
                  return buildMovieCard(watched[index], onMove: () => moveToWatchLater(watched[index]));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
