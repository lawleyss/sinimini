import 'dart:convert';  // For json.encode
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http; // For HTTP requests
import 'package:sinimini_app/main.dart'; // Ensure MyApp.accentColor and MyApp.primaryColor are defined here.

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLoginMode = true;
  final _profileController = TextEditingController();
  final _passwordController = TextEditingController();

  final double _buttonBorderRadius = 15.0;

  // Function to handle form submission
  Future<void> _submit() async {
    final profileName = _profileController.text.trim();
    final password = _passwordController.text.trim();

    if (profileName.isNotEmpty && password.isNotEmpty) {
      try {
        final response = await http.post(
          Uri.parse(_isLoginMode
              ? 'http://localhost:5000/login'
              : 'http://localhost:5000/register'),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'username': profileName,
            'password': password,
          }),
        );

        final responseBody = json.decode(response.body);

        if (response.statusCode == 200 || response.statusCode == 201) {
          // If login or registration is successful, navigate or show success
          Navigator.of(context).pop(profileName);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(responseBody['message'])),
          );
        } else {
          // Handle errors
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(responseBody['message'])),
          );
        }
      } catch (error) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("An error occurred. Please try again.")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in both fields.")),
      );
    }
  }

  @override
  void dispose() {
    _profileController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // Button helper for styling the buttons
  Widget buildButton(String text, Color color, VoidCallback onPressed,
      {Color textColor = Colors.white, bool bold = false}) {
    return SizedBox(
      width: double.infinity,
      height: 70,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(_buttonBorderRadius),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: textColor,
            fontWeight: bold ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(240, 240, 240, 1),
      appBar: AppBar(
        title: Text(_isLoginMode ? "Log In" : "Register"),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(15),
          margin: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Profile Name TextField
              TextField(
                controller: _profileController,
                decoration: const InputDecoration(
                  labelText: "Profile Name",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              // Password TextField
              TextField(
                controller: _passwordController,
                decoration: const InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
              ),
              const SizedBox(height: 20),
              // Submit button using MyApp.accentColor
              buildButton(
                _isLoginMode ? "Log In" : "Register",
                MyApp.accentColor,
                _submit,
                textColor: Colors.white,
                bold: true,
              ),
              const SizedBox(height: 10),
              // Toggle between login and register
              buildButton(
                _isLoginMode
                    ? "Don't have an account? Register"
                    : "Already have an account? Log In",
                MyApp.primaryColor,
                () {
                  setState(() {
                    _isLoginMode = !_isLoginMode;
                  });
                },
                textColor: Colors.black,
                bold: false,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
